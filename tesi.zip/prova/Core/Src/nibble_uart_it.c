/* =====================================================================
 * nibble_uart_it.c — Driver UART a interrupt per Nibble-O / STM32F401RE
 *
 * Ricezione: interrupt byte-per-byte (HAL_UART_Receive_IT con 1 byte).
 *   Ogni byte ricevuto viene accumulato in un buffer circolare.
 *   Quando arriva il CR ('\r'), il frame è completo.
 *
 * Trasmissione: polling (i comandi sono pochi byte, non serve interrupt).
 *
 * Flusso tipico:
 *   1. Nibble_SendCmd("V")       → invia comando
 *   2. IRQ accumula byte         → automatico
 *   3. main loop: if (Nibble_GetState() == NIBBLE_STATE_INFO_READY) ...
 *   4. Nibble_ResetState()       → pronto per il prossimo comando
 * ===================================================================== */

#include "nibble_uart_it.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <stdio.h>
static void Nibble_ParseFrame_IT(void);
/* --- Handle UART ------------------------------------------------------ */
static UART_HandleTypeDef *h_nibble;   /* USART2 → Nibble-O              */
static UART_HandleTypeDef *h_debug;    /* USART1 → PC (debug/monitor)    */

/* --- Buffer di ricezione ---------------------------------------------- */
static uint8_t  rx_byte;                          /* singolo byte IRQ     */
static uint8_t  rx_buf[NIBBLE_RX_BUF_SIZE];       /* buffer accumulazione */
static volatile uint16_t rx_idx = 0;
uint8_t nibble_term_mode = 0; /* 0=CR, 1=CRLF, 2=LF, 3=nessuno */              /* indice scrittura     */
static volatile Nibble_State_t state = NIBBLE_STATE_IDLE;

/* --- Dati parsati ----------------------------------------------------- */
static Nibble_Frame_t frame;
static char info_response[64];

/* --- Riferimenti per calibrazione ------------------------------------- */
static int32_t dark_ref[NIBBLE_NUM_CH];
static int32_t white_ref[NIBBLE_NUM_CH];
static bool    has_dark  = false;
static bool    has_white = false;

/* === Utility: stampa debug su USART1 ================================== */
static void dbg(const char *msg)
{
    if (h_debug != NULL) {
        HAL_UART_Transmit(h_debug, (uint8_t *)msg, (uint16_t)strlen(msg), 50);
    }
}

/* === INIT ============================================================= */
void Nibble_Init(UART_HandleTypeDef *huart_nibble,
                 UART_HandleTypeDef *huart_debug)
{
    h_nibble = huart_nibble;
    h_debug  = huart_debug;

    memset(&frame, 0, sizeof(frame));
    memset(rx_buf, 0, sizeof(rx_buf));
    rx_idx = 0;
    state  = NIBBLE_STATE_IDLE;

    /* Avvia la ricezione interrupt: 1 byte alla volta */
    HAL_UART_Receive_IT(h_nibble, &rx_byte, 1);

    dbg("[NIBBLE] Init OK — in attesa di comandi\r\n");
}

/* === STATO ============================================================ */
Nibble_State_t Nibble_GetState(void)
{
    return state;
}

void Nibble_ResetState(void)
{
    rx_idx = 0;
    state  = NIBBLE_STATE_IDLE;
}

/* === INVIO COMANDO ==================================================== */
void Nibble_SendCmd(const char *cmd)
{
    /* Reset buffer ricezione */
    rx_idx = 0;
    memset(rx_buf, 0, sizeof(rx_buf));
    state = NIBBLE_STATE_WAITING;

    /* Trasmetti il comando */
    HAL_UART_Transmit(h_nibble, (uint8_t *)cmd, (uint16_t)strlen(cmd), 100);

    /* Trasmetti il terminatore secondo nibble_term_mode */
    if (nibble_term_mode == 0)      { uint8_t t=0x0D; HAL_UART_Transmit(h_nibble, &t, 1, 100); }
    else if (nibble_term_mode == 1) { uint8_t t[2]={0x0D,0x0A}; HAL_UART_Transmit(h_nibble, t, 2, 100); }
    else if (nibble_term_mode == 2) { uint8_t t=0x0A; HAL_UART_Transmit(h_nibble, &t, 1, 100); }
    /* mode 3 = nessun terminatore *//* Log su debug */
    char tmp[48];
    snprintf(tmp, sizeof(tmp), "[TX] > %s\r\n", cmd);
    dbg(tmp);
}

/* === CALLBACK INTERRUPT RICEZIONE ===================================== *
 *
 * Questa funzione viene chiamata automaticamente dall'HAL ogni volta
 * che un byte arriva su USART2. Deve essere richiamata da
 * HAL_UART_RxCpltCallback() nel file main.c (vedi esempio sotto).
 *
 * Funzionamento:
 *   - Accumula ogni byte nel buffer rx_buf
 *   - Quando riceve '\r' (CR), il messaggio è completo
 *   - Determina il tipo di risposta (frame dati o testo)
 *   - Aggiorna lo stato
 *   - Ri-arma l'interrupt per il byte successivo
 * ====================================================================== */

/* Gestione errori UART: pulisce i flag di errore e ri-arma la ricezione.
   Da chiamare da HAL_UART_ErrorCallback nel main. */
void Nibble_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart != h_nibble) return;
    /* pulisce i flag di errore (overrun, framing, noise) */
    __HAL_UART_CLEAR_OREFLAG(huart);
    __HAL_UART_CLEAR_NEFLAG(huart);
    __HAL_UART_CLEAR_FEFLAG(huart);
    /* ri-arma la ricezione */
    HAL_UART_Receive_IT(h_nibble, &rx_byte, 1);
}

void Nibble_RxCallback(UART_HandleTypeDef *huart)
{
    if (huart != h_nibble) return;

    /* DEBUG: segnala su USART1 (PC) che e' arrivato un byte dal Nibble */
    if (h_debug != NULL) {
        char db[24];
        snprintf(db, sizeof(db), "[RX:%02X]", rx_byte);
        HAL_UART_Transmit(h_debug, (uint8_t*)db, strlen(db), 5);
    }

    /* Accumula il byte ricevuto */
    if (rx_idx < NIBBLE_RX_BUF_SIZE - 1) {
        rx_buf[rx_idx++] = rx_byte;
    }

    /* Controlla se è il terminatore CR */
    if (rx_byte == '\r') {
        rx_buf[rx_idx] = '\0';   /* termina la stringa */

        if (rx_idx >= NIBBLE_FRAME_SIZE - 10) {
            /* Risposta lunga → frame dati (comando S o T) */
            Nibble_ParseFrame_IT();
            state = NIBBLE_STATE_FRAME_READY;
        }
        else if (rx_idx >= 1 && rx_buf[0] == '0') {
            /* ACK */
            state = NIBBLE_STATE_ACK;
        }
        else if (rx_idx >= 1 && rx_buf[0] == '1') {
            /* NACK */
            state = NIBBLE_STATE_NACK;
        }
        else {
            /* Risposta testuale (V, I, H, ecc.) */
            uint16_t copy = (rx_idx < sizeof(info_response) - 1)
                            ? rx_idx : sizeof(info_response) - 1;
            memcpy(info_response, rx_buf, copy);
            info_response[copy] = '\0';
            state = NIBBLE_STATE_INFO_READY;
        }
    }

    /* RI-ARMA l'interrupt per il prossimo byte */
    HAL_UART_Receive_IT(h_nibble, &rx_byte, 1);
}

/* === PARSING DEL FRAME (§5.3 del manuale) ============================= */
static void Nibble_ParseFrame_IT(void)
{
    char tmp[16];

    /* 16 canali: byte 6+n*14 .. 13+n*14 (1-indexed) */
    for (int n = 0; n < NIBBLE_NUM_CH; n++) {
        int start = 6  + n * 14;     /* 1-indexed */
        int end   = 13 + n * 14;     /* 1-indexed, inclusivo */
        int L     = end - start + 1; /* = 8 */

        if (start - 1 + L > (int)rx_idx) {
            frame.ch_raw[n] = 0;
            continue;
        }

        memcpy(tmp, &rx_buf[start - 1], (size_t)L);
        tmp[L] = '\0';
        frame.ch_raw[n] = atoi(tmp);
    }

    /* Integration setting: byte 224..226 */
    if (rx_idx >= 226) {
        memcpy(tmp, &rx_buf[223], 3);
        tmp[3] = '\0';
        frame.integration_set = (uint16_t)atoi(tmp);
    }

    /* Lamp limit: byte 227..235 */
    if (rx_idx >= 235) {
        memcpy(tmp, &rx_buf[226], 9);
        tmp[9] = '\0';
        frame.lamp_limit = (uint16_t)atoi(tmp);
    }

    /* Temperatura MCU: byte 245..253 */
    if (rx_idx >= 253) {
        memcpy(tmp, &rx_buf[244], 9);
        tmp[9] = '\0';
        frame.mcu_temp_C = (float)atof(tmp);
    }
}

/* === ACCESSO AI DATI ================================================== */
Nibble_Frame_t* Nibble_GetFrame(void)
{
    return &frame;
}

const char* Nibble_GetInfoResponse(void)
{
    return info_response;
}

/* === CALIBRAZIONE: DARK E WHITE REFERENCE ============================= */
void Nibble_StoreDarkRef(void)
{
    for (int i = 0; i < NIBBLE_NUM_CH; i++) {
        dark_ref[i] = frame.ch_raw[i];
    }
    has_dark = true;
    dbg("[CAL] Dark reference salvata\r\n");
}

void Nibble_StoreWhiteRef(void)
{
    for (int i = 0; i < NIBBLE_NUM_CH; i++) {
        white_ref[i] = frame.ch_raw[i];
    }
    has_white = true;
    dbg("[CAL] White reference salvata\r\n");
}

/* === PRE-PROCESSING: WHITE CORRECTION + SNV =========================== *
 *
 * Step 1: White Correction (§6.2 del manuale Nibble)
 *   WC_i = (Raw_i - Dark_i) / (White_i - Dark_i)
 *
 * Step 2: SNV (§2.2 del paper Lossa et al.)
 *   SNV_i = (WC_i - media) / deviazione_standard
 *
 * Dopo questa funzione, frame.ch_snv[] contiene il vettore a 16
 * dimensioni pronto per essere passato al modello di classificazione.
 * ====================================================================== */
void Nibble_ApplyPreprocessing(void)
{
    /* --- Step 1: White Correction --- */
    if (has_dark && has_white) {
        for (int i = 0; i < NIBBLE_NUM_CH; i++) {
            int32_t denom = white_ref[i] - dark_ref[i];
            if (denom != 0) {
                frame.ch_wc[i] = (float)(frame.ch_raw[i] - dark_ref[i])
                                 / (float)denom;
            } else {
                frame.ch_wc[i] = 0.0f;
            }
        }
    } else {
        /* Senza riferimenti: usa raw normalizzato come fallback */
        for (int i = 0; i < NIBBLE_NUM_CH; i++) {
            frame.ch_wc[i] = (float)frame.ch_raw[i];
        }
        dbg("[WARN] Manca dark/white ref — WC non applicata\r\n");
    }

    /* --- Step 2: SNV --- */
    /* Calcola media dei 16 canali WC */
    float mean = 0.0f;
    for (int i = 0; i < NIBBLE_NUM_CH; i++) {
        mean += frame.ch_wc[i];
    }
    mean /= (float)NIBBLE_NUM_CH;

    /* Calcola deviazione standard */
    float var = 0.0f;
    for (int i = 0; i < NIBBLE_NUM_CH; i++) {
        float diff = frame.ch_wc[i] - mean;
        var += diff * diff;
    }
    float std = sqrtf(var / (float)(NIBBLE_NUM_CH - 1));

    /* Applica SNV */
    if (std > 1e-8f) {
        for (int i = 0; i < NIBBLE_NUM_CH; i++) {
            frame.ch_snv[i] = (frame.ch_wc[i] - mean) / std;
        }
    } else {
        for (int i = 0; i < NIBBLE_NUM_CH; i++) {
            frame.ch_snv[i] = 0.0f;
        }
        dbg("[WARN] StdDev ~0 — SNV non applicata\r\n");
    }
}

/* === DEBUG: STAMPA FRAME SU USART1 ==================================== */
void Nibble_DebugPrintFrame(void)
{
    char line[80];

    dbg("--- FRAME NIBBLE ---\r\n");
    for (int i = 0; i < NIBBLE_NUM_CH; i++) {
        snprintf(line, sizeof(line),
                 "CH%02d  raw=%ld  WC=%.5f  SNV=%.4f\r\n",
                 i + 1, (long)frame.ch_raw[i],
                 frame.ch_wc[i], frame.ch_snv[i]);
        dbg(line);
    }
    snprintf(line, sizeof(line),
             "IntSet=%u  LampLim=%u  Temp=%.2f C\r\n",
             frame.integration_set, frame.lamp_limit, frame.mcu_temp_C);
    dbg(line);
    dbg("--------------------\r\n");
}
