/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body - Acquisizione reale dal Nibble
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"

/* USER CODE BEGIN Includes */
#include "ai_platform.h"
#include "network.h"
#include "network_data.h"
#include "nibble_uart_it.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
/* USER CODE END Includes */

/* USER CODE BEGIN PTD */
/* ===== CARATTERIZZAZIONE TEMPORALE (par. 6.5) ===== */
#define BENCHMARK       1     /* 1 = esegue anche le misure ripetute, 0 = solo il ciclo normale */
#define BENCH_N         100   /* ripetizioni per pre-processing e inferenza            */
#define BENCH_COMM_N    10    /* acquisizioni consecutive per il tempo di comunicazione */
#define COMM_TIMEOUT_MS 5000  /* timeout di attesa del frame                            */

typedef enum {
    LIVE_IDLE,
    LIVE_DARK,
    LIVE_WAIT_WHITE,
    LIVE_WHITE,
    LIVE_WAIT_SAMPLE,
    LIVE_PREDICTION
} Live_State_t;
/* USER CODE END PTD */

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
ai_handle network;
ai_u8 activations[AI_NETWORK_DATA_ACTIVATIONS_SIZE];
ai_buffer *ai_input;
ai_buffer *ai_output;
float ai_out_data[AI_NETWORK_OUT_1_SIZE];
float array_16_float[16];

long live_dark[16];
long live_white[16];

Live_State_t live_state = LIVE_IDLE;
volatile uint8_t start_acquisition = 0;
volatile uint32_t last_b1_tick = 0;

/* --- misura dei tempi --- */
uint32_t t_c0 = 0;                     /* istante di invio del comando S del campione */
typedef struct { double sum, sum2; uint32_t max, n; } Stat_t;
/* USER CODE END PV */

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void Debug_Print(const char *msg);
static void DWT_Init(void);
static void Preprocess(const long *raw, float *wc, float *snv);
static void Stat_Add(Stat_t *s, uint32_t cyc);
static void Stat_Print(const char *nome, const Stat_t *s);
static void Benchmark_Run(const long *raw);

/* Stampa sul terminale PC (USART2, cavo USB) */
static void Debug_Print(const char *msg)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)msg, (uint16_t)strlen(msg), 1000);
}

/* ---------- Contatore di cicli DWT: risoluzione 1/84 MHz = 11,9 ns ---------- */
static void DWT_Init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;   /* abilita il blocco trace */
    DWT->CYCCNT = 0;                                   /* azzera il contatore     */
    DWT->CTRL  |= DWT_CTRL_CYCCNTENA_Msk;              /* avvia il conteggio      */
}

/* cicli -> microsecondi con 2 decimali, senza printf dei float */
static void Us_Str(char *buf, size_t len, double cyc)
{
    double us = cyc * 1e6 / (double)SystemCoreClock;
    unsigned long ip = (unsigned long)us;
    unsigned long dp = (unsigned long)((us - ip) * 100.0 + 0.5);
    if (dp >= 100) { ip++; dp -= 100; }
    snprintf(buf, len, "%lu.%02lu us", ip, dp);
}

/* ---------- Pre-processing: correzione White/Dark + SNV (SENZA stampe) ----------
 * Stessa identica pipeline di prima, spostata in una funzione cosi' da poterla
 * cronometrare senza includere il tempo delle Debug_Print.                      */
static void Preprocess(const long *raw, float *wc, float *snv)
{
    /* White Correction: WC = (Raw - Dark) / (White - Dark) */
    for (int i = 0; i < 16; i++) {
        float den = (float)(live_white[i] - live_dark[i]);
        wc[i] = (den != 0.0f) ? (float)(raw[i] - live_dark[i]) / den : 0.0f;
    }
    /* SNV: (x - media) / dev_std */
    float mean = 0;
    for (int i = 0; i < 16; i++) mean += wc[i];
    mean /= 16.0f;
    float sc = 0;
    for (int i = 0; i < 16; i++) sc += (wc[i] - mean) * (wc[i] - mean);
    float dev = sqrtf(sc / 15.0f);
    if (dev == 0.0f) dev = 1e-6f;
    for (int i = 0; i < 16; i++) snv[i] = (wc[i] - mean) / dev;
}

/* ---------- Statistiche: media, deviazione standard, massimo ---------- */
static void Stat_Add(Stat_t *s, uint32_t cyc)
{
    s->sum  += cyc;
    s->sum2 += (double)cyc * (double)cyc;
    if (cyc > s->max) s->max = cyc;
    s->n++;
}

static void Stat_Print(const char *nome, const Stat_t *s)
{
    if (s->n < 2) return;
    double media = s->sum / s->n;
    double var   = (s->sum2 - s->n * media * media) / (s->n - 1);
    double dev   = sqrt(var > 0 ? var : 0);
    char a[24], b[24], c[24], m[140];
    Us_Str(a, sizeof(a), media);
    Us_Str(b, sizeof(b), dev);
    Us_Str(c, sizeof(c), (double)s->max);
    snprintf(m, sizeof(m), "  %-15s N=%3lu | media = %s | dev.std = %s | max = %s\r\n",
             nome, (unsigned long)s->n, a, b, c);
    Debug_Print(m);
}

/* ---------- Misure ripetute ---------- */
static void Benchmark_Run(const long *raw)
{
    Stat_t st_pre = {0}, st_inf = {0}, st_comm = {0};
    float wc_b[16];
    char m[120];

    snprintf(m, sizeof(m), "\r\n=== BENCHMARK TEMPI (f_clk = %lu MHz) ===\r\n",
             (unsigned long)(SystemCoreClock / 1000000UL));
    Debug_Print(m);

    /* 1) Pre-processing e inferenza: BENCH_N ripetizioni sul campione appena acquisito.
     *    Il ciclo k = 0 e' di riscaldamento (warm-up) e viene scartato.                */
    for (uint32_t k = 0; k <= BENCH_N; k++) {
        uint32_t c0 = DWT->CYCCNT;
        Preprocess(raw, wc_b, array_16_float);
        uint32_t c1 = DWT->CYCCNT;
        ai_input[0].data  = AI_HANDLE_PTR(array_16_float);
        ai_output[0].data = AI_HANDLE_PTR(ai_out_data);
        ai_network_run(network, ai_input, ai_output);
        uint32_t c2 = DWT->CYCCNT;
        if (k > 0) { Stat_Add(&st_pre, c1 - c0); Stat_Add(&st_inf, c2 - c1); }
    }

    /* 2) Comunicazione: BENCH_COMM_N acquisizioni consecutive (lasciare il campione in posizione) */
    Debug_Print("  Misura della comunicazione in corso (lasciare il campione in posizione)...\r\n");
    for (uint32_t j = 0; j < BENCH_COMM_N; j++) {
        Nibble_ResetState();
        uint32_t tick0 = HAL_GetTick();
        uint32_t c0 = DWT->CYCCNT;
        Nibble_SendCmd("S");
        while (Nibble_GetState() != NIBBLE_STATE_FRAME_READY) {
            if (HAL_GetTick() - tick0 > COMM_TIMEOUT_MS) break;
        }
        uint32_t c1 = DWT->CYCCNT;
        if (Nibble_GetState() == NIBBLE_STATE_FRAME_READY) Stat_Add(&st_comm, c1 - c0);
        else Debug_Print("  [timeout frame]\r\n");
        HAL_Delay(50);   /* pausa tra due misure, fuori dall'intervallo cronometrato */
    }

    Stat_Print("Comunicazione", &st_comm);
    Stat_Print("Pre-processing", &st_pre);
    Stat_Print("Inferenza", &st_inf);
    Debug_Print("=== FINE BENCHMARK ===\r\n");
}

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_USART1_UART_Init();
    MX_USART2_UART_Init();

    /* USER CODE BEGIN 2 */
    /* Inizializzazione del driver Nibble: comunicazione su USART1, debug su USART2 */
    Nibble_Init(&huart1, &huart2);
    live_state = LIVE_IDLE;

    /* LED di stato */
    __HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin   = GPIO_PIN_5;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* Inizializzazione della rete neurale (X-CUBE-AI) */
    ai_network_create(&network, AI_NETWORK_DATA_CONFIG);
    ai_network_params network_params = {0};
    network_params.activations.data = AI_HANDLE_PTR(activations);
    network_params.params.data = AI_HANDLE_PTR(ai_network_data_weights_get());
    ai_network_init(network, &network_params);
    ai_input  = ai_network_inputs_get(network, NULL);
    ai_output = ai_network_outputs_get(network, NULL);

    DWT_Init();                          /* contatore di cicli per la misura dei tempi */

    HAL_Delay(500);
    Debug_Print("\r\n[SISTEMA PRONTO]\r\nPremi B1 per acquisire il DARK.\r\n");
    /* USER CODE END 2 */

    while (1)
    {
        /* USER CODE BEGIN 3 */
        switch (live_state)
        {
        /* ---- IDLE: alla pressione di B1 invia il comando di acquisizione DARK ---- */
        case LIVE_IDLE:
            if (start_acquisition == 1) {
                start_acquisition = 0;
                HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
                Nibble_SendCmd("S");            /* comando di misura al Nibble */
                live_state = LIVE_DARK;
            }
            break;

        /* ---- DARK: attende il frame del Nibble e memorizza il riferimento scuro ---- */
        case LIVE_DARK:
            if (Nibble_GetState() == NIBBLE_STATE_FRAME_READY) {
                Nibble_Frame_t *f = Nibble_GetFrame();
                Debug_Print("\r\n>>> ACQUISIZIONE DARK COMPLETATA\r\nValori DARK (16 canali):\r\n");
                char b[80];
                for (int i = 0; i < 16; i++) {
                    live_dark[i] = f->ch_raw[i];    /* valori REALI dal Nibble */
                    snprintf(b, sizeof(b), "  CH%02d = %ld\r\n", i + 1, live_dark[i]);
                    Debug_Print(b);
                }
                Nibble_ResetState();
                Debug_Print("\r\n>>> Posiziona la WHITE REFERENCE e premi B1\r\n");
                live_state = LIVE_WAIT_WHITE;
            }
            break;

        /* ---- WAIT_WHITE: alla pressione di B1 invia il comando per il WHITE ---- */
        case LIVE_WAIT_WHITE:
            if (start_acquisition == 1) {
                start_acquisition = 0;
                Nibble_SendCmd("S");
                live_state = LIVE_WHITE;
            }
            break;

        /* ---- WHITE: attende il frame e memorizza il riferimento bianco ---- */
        case LIVE_WHITE:
            if (Nibble_GetState() == NIBBLE_STATE_FRAME_READY) {
                Nibble_Frame_t *f = Nibble_GetFrame();
                Debug_Print("\r\n>>> ACQUISIZIONE WHITE COMPLETATA\r\nValori WHITE (16 canali):\r\n");
                char b[80];
                for (int i = 0; i < 16; i++) {
                    live_white[i] = f->ch_raw[i];   /* valori REALI dal Nibble */
                    snprintf(b, sizeof(b), "  CH%02d = %ld\r\n", i + 1, live_white[i]);
                    Debug_Print(b);
                }
                Nibble_ResetState();
                Debug_Print("\r\n>>> Rimuovi la reference, posiziona il CAMPIONE e premi B1\r\n");
                live_state = LIVE_WAIT_SAMPLE;
            }
            break;

        /* ---- WAIT_SAMPLE: alla pressione di B1 invia il comando per il CAMPIONE ---- */
        case LIVE_WAIT_SAMPLE:
            if (start_acquisition == 1) {
                start_acquisition = 0;
                t_c0 = DWT->CYCCNT;             /* INIZIO misura: invio comando campione */
                Nibble_SendCmd("S");
                live_state = LIVE_PREDICTION;
            }
            break;

        /* ---- PREDICTION: frame campione -> correzione + SNV + inferenza reale ---- */
        case LIVE_PREDICTION:
            if (Nibble_GetState() == NIBBLE_STATE_FRAME_READY) {
                uint32_t c1 = DWT->CYCCNT;      /* FINE comunicazione            */

                Nibble_Frame_t *f = Nibble_GetFrame();
                long sample_raw[16];
                for (int i = 0; i < 16; i++) sample_raw[i] = f->ch_raw[i];

                /* --- Pre-processing: White Correction + SNV (cronometrato, senza stampe) --- */
                float wc[16];
                Preprocess(sample_raw, wc, array_16_float);
                uint32_t c2 = DWT->CYCCNT;      /* FINE pre-processing           */

                /* --- INFERENZA REALE ON-DEVICE --- */
                ai_input[0].data  = AI_HANDLE_PTR(array_16_float);
                ai_output[0].data = AI_HANDLE_PTR(ai_out_data);
                ai_network_run(network, ai_input, ai_output);   /* la rete classifica davvero */
                uint32_t c3 = DWT->CYCCNT;      /* FINE inferenza                */

                /* --- Da qui in poi solo stampe: fuori dagli intervalli misurati --- */
                char b[100];
                Debug_Print("\r\n>>> ACQUISIZIONE CAMPIONE E PRE-PROCESSING...\r\n");
                Debug_Print("Valori White-Corrected:\r\n");
                for (int i = 0; i < 16; i++) {
                    snprintf(b, sizeof(b), "  CH%02d = %.5f\r\n", i + 1, wc[i]);
                    Debug_Print(b);
                }
                Debug_Print("\r\nValori SNV (Standard Normal Variate):\r\n");
                for (int i = 0; i < 16; i++) {
                    snprintf(b, sizeof(b), "  CH%02d = %.5f\r\n", i + 1, array_16_float[i]);
                    Debug_Print(b);
                }
                Debug_Print("\r\n--- INFERENZA TINYML ---\r\n");

                /* --- Interpretazione dell'uscita --- */
                int cmax = 0;
                for (int i = 1; i < 7; i++)
                    if (ai_out_data[i] > ai_out_data[cmax]) cmax = i;
                const char *nomi[7] = {"ACK","CBC","CEC","MEL","NEV","Others","SEK"};
                float confidenza = ai_out_data[cmax] * 100.0f;

                char msg[500];
                snprintf(msg, sizeof(msg),
                    "\r\n========================================\r\n"
                    "             RISULTATO FINALE           \r\n"
                    "========================================\r\n"
                    " Classe predetta : %s\r\n"
                    " Confidenza      : %.1f%%\r\n"
                    "----------------------------------------\r\n"
                    " Vettore Probabilita' Classi:\r\n"
                    "  - ACK    : %.3f\r\n"
                    "  - CBC    : %.3f\r\n"
                    "  - CEC    : %.3f\r\n"
                    "  - MEL    : %.3f\r\n"
                    "  - NEV    : %.3f\r\n"
                    "  - Others : %.3f\r\n"
                    "  - SEK    : %.3f\r\n"
                    "========================================\r\n",
                    nomi[cmax], confidenza,
                    ai_out_data[0], ai_out_data[1], ai_out_data[2],
                    ai_out_data[3], ai_out_data[4], ai_out_data[5], ai_out_data[6]);
                Debug_Print(msg);

                /* --- Tempi del ciclo appena eseguito --- */
                {
                    char s1[24], s2[24], s3[24], s4[24], tm[200];
                    Us_Str(s1, sizeof(s1), (double)(c1 - t_c0));
                    Us_Str(s2, sizeof(s2), (double)(c2 - c1));
                    Us_Str(s3, sizeof(s3), (double)(c3 - c2));
                    Us_Str(s4, sizeof(s4), (double)(c3 - t_c0));
                    snprintf(tm, sizeof(tm),
                        "\r\n--- TEMPI DEL CICLO ---\r\n"
                        "  t_comm = %s\r\n  t_pre  = %s\r\n  t_inf  = %s\r\n  t_tot  = %s\r\n",
                        s1, s2, s3, s4);
                    Debug_Print(tm);
                }

#if BENCHMARK
                Benchmark_Run(sample_raw);      /* misure ripetute: media, dev.std, max */
#endif

                HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
                Nibble_ResetState();
                Debug_Print("\r\n>>> CICLO TERMINATO. Premi B1 per un nuovo ciclo.\r\n");
                live_state = LIVE_IDLE;
                HAL_Delay(300);
            }
            break;

        default:
            live_state = LIVE_IDLE;
            break;
        }
        /* USER CODE END 3 */
    }
}

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM = 16;
    RCC_OscInitStruct.PLL.PLLN = 336;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
    RCC_OscInitStruct.PLL.PLLQ = 7;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) Error_Handler();
}

static void MX_USART1_UART_Init(void)
{
    huart1.Instance = USART1;
    huart1.Init.BaudRate = 115200;
    huart1.Init.WordLength = UART_WORDLENGTH_8B;
    huart1.Init.StopBits = UART_STOPBITS_1;
    huart1.Init.Parity = UART_PARITY_NONE;
    huart1.Init.Mode = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK) Error_Handler();
}

static void MX_USART2_UART_Init(void)
{
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 115200;
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK) Error_Handler();
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
    GPIO_InitStruct.Pin = B1_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = LD2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);
    HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    Nibble_RxCallback(huart);
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    Nibble_ErrorCallback(huart);
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == B1_Pin) {
        uint32_t now = HAL_GetTick();
        if (now - last_b1_tick < 300) return;   /* debounce */
        last_b1_tick = now;
        start_acquisition = 1;
    }
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) {}
}
