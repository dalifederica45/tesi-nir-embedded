#ifndef NIBBLE_UART_IT_H
#define NIBBLE_UART_IT_H

/* =====================================================================
 * Driver UART a INTERRUPT per Nibble-O su STM32F401RE
 *
 * Architettura:
 *   USART2 → Nibble-O   (UART diretta, 115200-8N1)
 *   USART1 → PC/debug   (per Open Serial Port Monitor)
 *
 * La ricezione avviene tramite interrupt (HAL_UART_RxCpltCallback),
 * NON in polling. Il main loop controlla un flag per sapere quando
 * un frame completo è disponibile.
 *
 * CubeMX: abilitare USART2 global interrupt in NVIC.
 * ===================================================================== */

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

/* --- Dimensioni buffer ------------------------------------------------ */
#define NIBBLE_FRAME_SIZE     253   /* byte del frame dati (§5.3 manuale)  */
#define NIBBLE_RX_BUF_SIZE    300   /* buffer ricezione con margine        */
#define NIBBLE_NUM_CH         16    /* canali ChipSense                    */

/* --- Struttura dati del frame parsato --------------------------------- */
typedef struct {
    int32_t  ch_raw[NIBBLE_NUM_CH];   /* valori raw per canale             */
    float    ch_wc[NIBBLE_NUM_CH];    /* white-corrected (dopo calibraz.)  */
    float    ch_snv[NIBBLE_NUM_CH];   /* dopo SNV                          */
    uint16_t integration_set;
    uint16_t lamp_limit;
    float    mcu_temp_C;
} Nibble_Frame_t;

/* --- Stato della macchina a stati della ricezione --------------------- */
typedef enum {
    NIBBLE_STATE_IDLE,        /* in attesa, nessun comando inviato        */
    NIBBLE_STATE_WAITING,     /* comando inviato, attendo risposta        */
    NIBBLE_STATE_FRAME_READY, /* frame completo ricevuto e pronto         */
    NIBBLE_STATE_ACK,         /* risposta ACK ricevuta                    */
    NIBBLE_STATE_NACK,        /* risposta NACK ricevuta                   */
    NIBBLE_STATE_INFO_READY,  /* risposta testuale pronta (V, I, H)      */
    NIBBLE_STATE_ERROR        /* timeout o errore di parsing              */
} Nibble_State_t;

/* --- API pubblica ----------------------------------------------------- */

/* Inizializza: passare gli handle delle due USART configurate in CubeMX */
void Nibble_Init(UART_HandleTypeDef *huart_nibble,   /* USART2 → Nibble */
                 UART_HandleTypeDef *huart_debug);    /* USART1 → PC    */

/* Stato corrente (il main loop fa polling su questo) */
Nibble_State_t Nibble_GetState(void);

/* Invia un comando al Nibble (es. "V", "I", "S", "14T", "1M") */
void Nibble_SendCmd(const char *cmd);

/* Recupera il frame parsato (valido solo se stato == FRAME_READY) */
Nibble_Frame_t* Nibble_GetFrame(void);

/* Recupera la risposta testuale (valido solo se stato == INFO_READY) */
const char* Nibble_GetInfoResponse(void);

/* Reset dello stato a IDLE (chiamare dopo aver letto il frame/info) */
void Nibble_ResetState(void);

/* Calibrazione: salvare dark e white reference */
void Nibble_StoreDarkRef(void);
void Nibble_StoreWhiteRef(void);

/* Applica white correction + SNV al frame corrente */
void Nibble_ApplyPreprocessing(void);

/* Callback: da chiamare dentro HAL_UART_RxCpltCallback in main.c */
void Nibble_RxCallback(UART_HandleTypeDef *huart);
void Nibble_ErrorCallback(UART_HandleTypeDef *huart);

/* Debug: stampa il frame corrente su USART1 */
void Nibble_DebugPrintFrame(void);

#endif /* NIBBLE_UART_IT_H */
