/**
  ******************************************************************************
  * @file    network_1784460246072_data_params.c
  * @author  AST Embedded Analytics Research Platform
  * @date    2026-07-19T17:43:26+0200
  * @brief   AI Tool Automatic Code Generator for Embedded NN computing
  ******************************************************************************
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  ******************************************************************************
  */

#include "network_1784460246072_data_params.h"


/**  Activations Section  ****************************************************/
ai_handle g_network_1784460246072_activations_table[1 + 2] = {
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
  AI_HANDLE_PTR(NULL),
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
};




/**  Weights Section  ********************************************************/
AI_ALIGNED(32)
const ai_u64 s_network_1784460246072_weights_array_u64[170] = {
  0x59004da20000a600U, 0x83819b008d000000U, 0x9d000051000000U, 0xb200000000000000U,
  0xa60099a50000abU, 0xac000000U, 0x4a99a0400000000U, 0x0U,
  0xa2000000U, 0xfc4bfc04519e0000U, 0x9800000000U, 0xaa610000U,
  0x0U, 0xabU, 0xae00000000a10000U, 0x980000000000U,
  0x0U, 0x9d0000000000U, 0x404b204U, 0xfcfcfcfc00000000U,
  0xa90000U, 0xac00009e045104U, 0xabfcaffc00009c00U, 0x599b0000000000U,
  0x994d00000000U, 0x690000000000a300U, 0xa800990096000000U, 0x94000096005d0000U,
  0x5c00005900U, 0xad0000009dU, 0x9d000000000000U, 0xfcfcfcaa00000000U,
  0xb3040404U, 0xa7000000U, 0x40404fca2000000U, 0x9604040404U,
  0x96009f00U, 0x510000004f00a600U, 0x9900000000U, 0x0U,
  0x5d00a9006300U, 0x0U, 0x0U, 0x58a8ad0000U,
  0x4eU, 0x9c00000000000000U, 0xafU, 0x0U,
  0x530000a3U, 0x4e99000000U, 0xaf000000b100b200U, 0x9cab004db04d00U,
  0x0U, 0x4d0000abaa000000U, 0x5c0000b100U, 0xaf0000fcfcfcfcU,
  0xae00000000000000U, 0x4f00a3a4U, 0xa8000000a8fcfcfcU, 0x0U,
  0x9c0000U, 0x40404fca8fca8fcU, 0x9e00a90000005551U, 0x5050505a8050505U,
  0x0U, 0x0U, 0x0U, 0x0U,
  0x0U, 0x0U, 0x0U, 0x0U,
  0x0U, 0x0U, 0x0U, 0x0U,
  0x0U, 0x0U, 0x0U, 0x0U,
  0x9e6e0000a15300U, 0x40004040000005cU, 0x5300006751U, 0x670000000000U,
  0x404000400000000U, 0x0U, 0x6d00000000aa00U, 0x404040461000000U,
  0x5f0000af520000U, 0x6700U, 0x40404045c009e00U, 0x54000000000000U,
  0x0U, 0x49504a28ea60000U, 0x60000000000000U, 0xa60000005cU,
  0x468000000U, 0x60fefe005e00a000U, 0x0U, 0x4040004adab0000U,
  0xa1fe5e00000000U, 0x646d000000000000U, 0x466040000000000U, 0x6d600000000000U,
  0xae00000000006cU, 0x53ae000000a5U, 0x4009e04U, 0x95000000000050U,
  0x650056000058U, 0x68590066af04U, 0x66ae00000000008aU, 0x55a197U,
  0x4009aU, 0x56U, 0xac00000000550000U, 0x5a5763000400U,
  0x940000U, 0x9d00540000U, 0x404U, 0x0U,
  0x5fU, 0x539a00009c0004U, 0xa70053000000U, 0x0U,
  0x4U, 0x94a300000000U, 0x570000a2a3U, 0xa00058046504a7U,
  0xa500a4fe00fefeU, 0x5d00fe9b00fe0000U, 0x81fe0000fefeU, 0xfefefea2000000feU,
  0xae02000202U, 0x2000200000200a4U, 0xac000200530202U, 0x6502020000000002U,
  0x505aa0505000505U, 0x505050505056605U, 0x505000505U, 0xac05050005590005U,
  0x4a9000404000404U, 0x404040404045904U, 0x9b00000404000404U, 0xa4045d0004549804U,
  0xfffffffbfffffffbU, 0xfffffff4fffffff3U, 0x5fffffff6U, 0xfffffffefffffff3U,
  0xfffffff8fffffff9U, 0xfffffffeffffffffU, 0xfffffffffffffffbU, 0xfffffffeffffffffU,
  0xfefbfbf5fef66eU, 0xfefa71ebfff8f8U, 0xf14ff8f800005600U, 0xfbfffb63f6aaf6U,
  0x58fa53fa00f8f95cU, 0xf8f7f800006e54U, 0xfbfb00fbf6f600f6U, 0xfafa00fafaf90059U,
  0xfaf800f800000000U, 0x9dfafbffa751faffU, 0xfcfcfbfffafc81ffU, 0xebf44fff00000000U,
  0x68f35994f5fdf3f3U, 0x53f6565af3f351f3U, 0x5900000053U, 0x8200000057U,
  0x4bffffffbeU, 0x59U,
};


ai_handle g_network_1784460246072_weights_table[1 + 2] = {
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
  AI_HANDLE_PTR(s_network_1784460246072_weights_array_u64),
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
};

